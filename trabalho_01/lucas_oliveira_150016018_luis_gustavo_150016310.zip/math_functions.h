#ifndef MATH_FUNTIONS_H
#define MATH_FUNTIONS_H

  #define DIV_ERROR -99999999

  int add (int number1, int number2);
  int subtract (int number1, int number2);
  int multiply (int number1, int number2);
  int divide (int number1, int number2);
  int calculate (char* operator, int number1, int number2);

#endif
